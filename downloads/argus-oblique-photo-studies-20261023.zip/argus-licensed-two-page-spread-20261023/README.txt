Argus: two licensed oblique-photo surface studies (2026-10-23)

Open index.html for the two-page spread. report.json records source hashes, source crop coordinates, face vertices, output files, and limits. Each case folder contains its preserved source preview, exact rectified face UVs, coarse OBJ/MTL proxy, and illustrative material maps and lit previews.

Photo 1: Grand Canyon National Park, “Grand Canyon National Park: Community Building (2014) 8247”
https://www.flickr.com/photos/50693818@N08/13230532283
License: Creative Commons Attribution 2.0 — https://creativecommons.org/licenses/by/2.0/

Photo 2: Robbie Sproule, “my office”
https://www.flickr.com/photos/85278812@N00/1725317
License: Creative Commons Attribution 2.0 — https://creativecommons.org/licenses/by/2.0/

Argus adaptations: perspective rectification, authored proxy meshes, source crops, base-color neutralization proxies, normal/height/roughness/AO/metallic priors, and lit thumbnails. The photos remain credited to their photographers. Face corners and material labels were authored by inspection. This is an experimental study; physical depth, occluded surfaces, illumination, and PBR values are not measured.
