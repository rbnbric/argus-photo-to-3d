# Argus gallery presentation research — 2026-10-22

The previous Devpost gallery used small images inside repeated dark cards. At thumbnail size the evidence became harder to judge than the decoration. The revised twelve-image set uses a plain paper field, thin rules, larger rasters, and one claim per page. Page 09 leads with the 2D-to-3D texture maker and photogrammetry-to-PBR material path, using the established four-material synthetic wall control: paint, plaster, brick, and mortar, each with its exact UV pull and lit orb/cube. Page 10 puts both licensed oblique-photo studies on one page as a WIP scene recombination of the same procedure.

## Industry references and what they mean here

| Reference | Established practice | Argus application |
|---|---|---|
| [Adobe Substance 3D Painter: Display settings](https://experienceleague.adobe.com/en/docs/substance-3d-painter/using/interface/display-settings/display-settings) | Lit material, single-channel, and mesh-map views are distinct inspection modes. | Show source-UV and geometry evidence beside lit previews; never let a beauty render stand in for a channel map. |
| [Adobe Substance 3D Designer: Working with 3D scenes](https://experienceleague.adobe.com/en/docs/substance-3d-designer/using/working-with-3d-scenes/working-with-3d-scenes) | Material previews can use a saved mesh, camera, and light scene state, including a standardized tiled sphere. | Pin camera, preview form, light direction, and tile scale across all material comparisons. |
| [Adobe OpenPBR overview](https://experienceleague.adobe.com/en/docs/substance-3d/general-knowledge/openpbr/openpbr-overview) | Materials should be checked under both neutral studio lighting and a more dramatic context. | Add a neutral-light qualification before using reconstructed scene lighting as a presentation result. |
| [Unreal Engine Material Instance Editor](https://dev.epicgames.com/documentation/unreal-engine/unreal-engine-material-instance-editor-ui) | Lit/unlit modes and sphere, plane, and cube preview primitives are standard inspection options. | The current sphere and cube pair is useful; a flat plane and solo base-color/normal/roughness/height views are the next channel sheet. |
| [Marmoset Toolbag: Lighting hard-surface assets](https://marmoset.co/posts/how-to-light-hard-surface-assets-in-toolbag/) | Presentation lighting is set to make shape and material properties readable, with deliberate cameras and a consistent setup. | Keep the material form and source evidence large, and record the preview rig instead of hiding it behind mood lighting. |

## Current truth boundary

The wall fixture is synthetic. Its sphere and cube previews use inferred normal and roughness values and an illustrative light proxy; they are **not** qualified physical capture-light renders. The fox gallery has a separate F81 light-fit attempt that remains review-only. Camera comparisons and the Nebius diagnostic receipt retain their own measurement contracts.

Page 09 uses only the synthetic wall fixture and is a material-extraction control, not recovered physical PBR. Page 10 uses Grand Canyon National Park's “Community Building” and Robbie Sproule's “my office,” both credited under CC BY 2.0 in the gallery receipt and `SURFACE-SOURCE-CREDITS.txt`. Its face UVs, proxy shapes, and material values are WIP proposals. The scene form is another recombination of the same UV and material procedure, not a separately qualified system. The earlier three-wall gallery page remains historical only because of source-rights uncertainty and should not be published.

## Next quality pass

Render the four materials in Blender under one saved neutral HDRI and a second saved scene light; include a flat plane, base color, normal, roughness, height, and final lit pass at matched tile scale. Put render engine, color transform, exposure, environment, camera, and material version in the image receipt. That would make the material pages resemble a production look-development review rather than a product mockup.
